#pragma once
#include "Camera.h"

class Engine
{
public:
	Engine();
	~Engine();

	// method declarations
	bool init();
	bool bufferModel();
	bool gameLoop();
	bool useShaders();
	GLuint loadTexture(const char* fileName);
	bool collides(const Object* o1, const Object* o2);

private:
	unsigned int vertCount;
	GLuint vertArr;
	GLFWwindow* GLFWwindowPtr;
	ShaderManager sm;
	GLuint* texIDs;
	vector<Object> objects;
	float currentTime;
	float prevFrameTime;
	float deltaTime;
	Camera cam;
};

